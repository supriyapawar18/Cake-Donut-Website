package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Role;
import com.app.pojos.Cake;
import com.app.pojos.Customer;

@Repository 
public class CustomerDaoImpl implements ICustomerDao {
	// dependency
	@Autowired 

	private EntityManager mgr;

	@Override
	public Customer authenticateUser(String em, String pass) {
		String jpql = "select c from Customer c where c.email = :em and c.password=:pass";
		return mgr.createQuery(jpql, Customer.class).
				setParameter("em", em).setParameter("pass", pass)
				.getSingleResult();
	}

	@Override
	public List<Customer> listAllCustomers() {
		String jpql="select c from Customer c where c.role=:rl";		
		return mgr.createQuery(jpql, Customer.class).setParameter("rl", Role.CUSTOMER).getResultList();
	}

	@Override
	public Customer getCustomerDetails(int customerId) {
		
		return mgr.find(Customer.class, customerId);
	}

	@Override
	public String deleteCustomerDetails(Customer c) {
		mgr.remove(c);
		return "Customer details with ID "+c.getId()+" deleted....";
	}

	@Override
	public String registerCustomer(Customer c) {
		String mesg="Customer registration failed....";
		mgr.persist(c);
		mesg="Customer registration successful "+c.getId();
		return mesg;
	}
	
	@Override
	public List<Cake> getAllCakes() {
		String jpql="select c from Cake c";
	    System.out.println("In dao cake list:"+ mgr.createQuery(jpql, Cake.class).getResultList());
		return mgr.createQuery(jpql, Cake.class).getResultList();
	}
}
