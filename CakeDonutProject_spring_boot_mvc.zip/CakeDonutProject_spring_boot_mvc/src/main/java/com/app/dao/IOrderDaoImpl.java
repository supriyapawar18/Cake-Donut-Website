package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Cake;
import com.app.pojos.Order;

@Repository
public class IOrderDaoImpl implements IOrderDao {
	@Autowired
	private EntityManager em;

	@Override
	public String saveOrder(Order order) {
		String msg="Order Failed";
		System.out.println("in orderdao");
		Order order1=em.merge(order);
		System.out.println("after save ..."+order1);
		msg="Order Registered";
		return msg;		
	}
	
}
