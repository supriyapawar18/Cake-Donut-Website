package com.app.dao;

import java.util.List;

import com.app.pojos.Cake;
import com.app.pojos.Order;

public interface IOrderDao {
	
	String saveOrder(Order order);

}
