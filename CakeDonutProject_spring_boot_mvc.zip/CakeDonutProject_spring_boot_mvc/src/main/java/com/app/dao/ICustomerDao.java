package com.app.dao;

import java.util.List;

import com.app.pojos.Cake;
import com.app.pojos.Customer;

public interface ICustomerDao {
	// add a method to authenticate user
	Customer authenticateUser(String em, String pass);

	// add a method to return a Customer list
	List<Customer> listAllCustomers();

	// add a method to get specific Customer details
	Customer getCustomerDetails(int customerId);

	// add a method to delete specific customer details
	String deleteCustomerDetails(Customer c);
	
	// add a method to register  new  customer details
	String registerCustomer(Customer c);
	
	//add a method to get all cakelist to view for customer
		List<Cake>getAllCakes();

}
