package com.app.dao;

import java.util.List;

import com.app.pojos.Cake;


public interface ICakeDao {

	// add a method to return a Cake list
	List<Cake> listAllCakes();

	// add a method to get specific Cake details
	Cake getCakeDetails(int cakeId);

	// add a method to delete specific cake details
	String deleteCakeDetails(Cake ck);
	
	// add a method to add  new cake details
	String addCake(Cake ck);

}