package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Cake;


@Repository 
public class CakeDaoImpl implements ICakeDao {
	// dependency
	@Autowired 
//	private SessionFactory sf;
	private EntityManager mgr;
	
	@Override
	public List<Cake> listAllCakes() {
		
		String jpql="select c from Cake c ";		
		System.out.println("In dao cake list:"+ mgr.createQuery(jpql, Cake.class).getResultList());
		return mgr.createQuery(jpql, Cake.class).getResultList();
	}

	@Override
	public Cake getCakeDetails(int cakeId) {
		System.out.println("DAO schecking cake by id"+mgr.find(Cake.class, cakeId));
		return mgr.find(Cake.class, cakeId);
	}

	@Override
	public String deleteCakeDetails(Cake ck) {
		mgr.remove(ck);
		
		return "Cake details with ID "+ck.getCakeId()+" deleted....";
	}

	@Override
	public String addCake(Cake ck) {
		String mesg="Cake addition failed....";
		mgr.persist(ck);
		mesg="Cake additiontion successful "+ck.getCakeId();
		return mesg;
	}


}
