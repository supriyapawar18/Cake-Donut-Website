package com.app.service;

import java.util.List;

import com.app.pojos.Cake;
import com.app.pojos.Order;

public interface IOrderService {
	String saveOrder(Order o);
	
}
