package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.ICustomerDao;
import com.app.pojos.Role;
import com.app.pojos.Cake;
import com.app.pojos.Customer;

@Service 
@Transactional 
public class CustomerServiceImpl implements ICustomerService {
	// dependency : DAO layer
	@Autowired
	private ICustomerDao customerDao;

	@Override
	public Customer authenticateUser(String em, String pass) {
		return customerDao.authenticateUser(em, pass);
	}

	@Override
	public List<Customer> listAllCustomers() {
		return customerDao.listAllCustomers();
	}

	@Override
	public String deleteCustomerDetails(int customerId) {
		// invoke dao layer's method to validate customer id
		Customer c = customerDao.getCustomerDetails(customerId);
		if (c == null)
			return "Customer deletion failed : invalid customer id";
		return customerDao.deleteCustomerDetails(c);
	}

	@Override
	public String registerCustomer(Customer c) {
		//set role
		c.setRole(Role.CUSTOMER);
		return customerDao.registerCustomer(c);
	}
	
	@Override
	public List<Cake> getAllCakes() {
		System.out.println("In service");
		return customerDao.getAllCakes();
	}

}
