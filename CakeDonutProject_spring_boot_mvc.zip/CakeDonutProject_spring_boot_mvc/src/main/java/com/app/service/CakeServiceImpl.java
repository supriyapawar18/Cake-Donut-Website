package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.ICakeDao;
import com.app.pojos.Cake;

@Service 
@Transactional 
public class CakeServiceImpl implements ICakeService {
	// dependency : DAO layer
	@Autowired
	private ICakeDao cakeDao;
	@Override
	public List<Cake> listAllCakes() {
		System.out.println("In service");
		return cakeDao.listAllCakes();
	}

	@Override
	public String deleteCakeDetails(int cakeId) {
		System.out.println("in delete cake details" );
		Cake ck = cakeDao.getCakeDetails(cakeId);
		if (ck == null)
			return "Cake deletion failed : invalid cake id";
		return cakeDao.deleteCakeDetails(ck);
	}

	@Override
	public String addCake(Cake ck) {
		return cakeDao.addCake(ck);
	}

//	@Override
//	public Object getCakeDetails(int cakeId) {
//		Cake ck = cakeDao.getCakeDetails(cakeId);
//		if (ck == null)
//			return "Cake view failed : invalid cake id";
//		return cakeDao.getCakeDetails(cakeId);
//	}
}
