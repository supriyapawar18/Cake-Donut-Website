package com.app.service;

import java.util.List;

import com.app.pojos.Cake;

public interface ICakeService {
	
		//add a method to return a cake list
		List<Cake> listAllCakes();
		//add a method to delete cake details
		String deleteCakeDetails(int cakeId);
		// add a method to add  new  cake details
		String addCake(Cake ck);
		
		
}
