package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IOrderDao;
import com.app.pojos.Cake;
import com.app.pojos.Order;
@Service
@Transactional
public class OrderServiceImpl implements IOrderService {
	@Autowired
	private IOrderDao iorderDao;

	@Override
	public String saveOrder(Order o) {
		System.out.println("in order service");
	return iorderDao.saveOrder(o);
	}	

}
