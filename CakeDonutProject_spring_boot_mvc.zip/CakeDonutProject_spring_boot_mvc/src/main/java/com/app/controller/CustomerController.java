package com.app.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Role;
import com.app.pojos.Customer;
import com.app.service.ICustomerService;

@Controller
@RequestMapping("/customer")  
public class CustomerController {
	
	@Autowired
	private ICustomerService customerService;

	public CustomerController() {
		System.out.println("in ctor " + getClass().getName());
	}
	
	@GetMapping("/register")
	public String showCustomerRegistrationForm(Model map)
	{
		System.out.println("in show reg form");
		map.addAttribute("customer_dtls", new Customer());
		System.out.println("map "+map); 
		return "/customer/register";
	}

@PostMapping("/register")
	public String processRegFrom(@Valid Customer c, BindingResult result, RedirectAttributes flashMap) {
		System.out.println("in process reg form " + c); 
		System.out.println("binding result " + result);
		c.setRole(Role.valueOf("CUSTOMER"));
		if(result.hasErrors())
		{
			System.out.println("P.L errors"+result.toString());
			
			return "/index";
		}
		flashMap.addFlashAttribute("message", customerService.registerCustomer(c));
		return "redirect:/";
	}

	@GetMapping("/login")
	public String showLoginForm() {
		System.out.println("in show login form");
		return "/customer/login";// actual view name : /WEB-INF/views/customer/login.jsp
	}
	
	@PostMapping("/login")
	public String processLoginForm(@RequestParam String email, @RequestParam String password,
			Model map,HttpSession session) {
		System.out.println("in process login form " + email + " " + password);
		// invoke service's method for validation
		try {
			Customer validatedUser = customerService.authenticateUser(email, password);
			session.setAttribute("message", validatedUser.getRole() + " login successful!");
			//add validated customer details in session scope , to remember it till logout
			session.setAttribute("customer", validatedUser);
			
			if (validatedUser.getRole().equals(Role.CUSTOMER))
				return "redirect:/products";	
			return "redirect:/admin/adminMenu";

		} catch (RuntimeException e) {
			e.printStackTrace();
			map.addAttribute("message", "Invalid Login , Please Retry");
			// forward the client to login page , highlighted with error mesg.
			return "/customer/login";// actual view name : /WEB-INF/views/customer/login.jsp
		}
	}
	

	@GetMapping("/cakecustomerlist")
	public String listCustomerCake(Model map2) {
		System.out.println("in customercakelist...");
		System.out.println("in custCakelist" +customerService.getAllCakes());
		map2.addAttribute("customercakelist", customerService.getAllCakes());
		return "/customer/cakecustomerlist";	
}

}
