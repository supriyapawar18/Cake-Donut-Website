package com.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.FlashMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Cake;
import com.app.pojos.Customer;
import com.app.pojos.Order;
import com.app.service.ICakeService;
import com.app.service.ICustomerService;
import com.app.service.IOrderService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	//dependency : service layer i/f
	@Autowired
	private ICustomerService customerService;
	@Autowired
	private ICakeService cakeService;

	public AdminController() {
		System.out.println("in ctor of "+getClass().getName());
	}
	//add a req handling method to list all customers
	@GetMapping("/customerList")
	public String listCustomers(Model map)
	{
		System.out.println("in list customers...");
		map.addAttribute("customer_list",customerService.listAllCustomers());
		return "/admin/customerList";//actual view name : /WEB-INF/views/admin/customerList.jsp
	}
	//add a req handling method to delete a specific customer n REDIRECT to list page 
	@GetMapping("/delete")
	public String deleteCustomerDetails(@RequestParam int cid,RedirectAttributes flashMap)
	{
		System.out.println("in del customer dtls "+cid);
		//Adding an attribute under flash scope (visible till the next request coming from SAME clnt)
		flashMap.addFlashAttribute("message",customerService.deleteCustomerDetails(cid));
		return "redirect:/admin/customerList";//URL of the next request : http://localhost:7070/spring-mvc-boot/admin/customerList 
	}
	
	@GetMapping("/addCake")
	public String showAddCakeForm(Model map1)
	{
		System.out.println("in show cake add form");
		map1.addAttribute("cake_dtls", new Cake());
		System.out.println("map "+map1);//populated map 
		return "/cake/addCake";//actual view name : /WEB-INF/views/cake/addCake.jsp
	}
	@PostMapping("/addCakes")
	public String processAddCakeFrom(Model map1 ,@RequestParam("file") MultipartFile file, @Valid Cake ck, BindingResult result1, RedirectAttributes flashMap) {
		System.out.println("in process cake add form " + ck); 
		System.out.println("binding result " + result1);
		List<Cake> cakeList= cakeService.listAllCakes();
		map1.addAttribute("cakeLists", cakeList);
		
		if(result1.hasErrors())
		{
			System.out.println("P.L errors"+result1.toString());
			
			return "/index";
		}
	
		flashMap.addFlashAttribute("message", cakeService.addCake(ck));
		return "/admin/cakeList";
	}
	@GetMapping("/cakeList")
	public String listCakes(Model map1)
	{
		System.out.println("in list cakes...");
		System.out.println("List of cakes:"+cakeService.listAllCakes());
		map1.addAttribute("cakeLists",cakeService.listAllCakes());
		return "/admin/cakeList";//actual view name : /WEB-INF/views/admin/cakeList.jsp
	}
	@GetMapping("/deleteCake")
	public String deleteCakeDetails(@RequestParam int cakeId,RedirectAttributes flashMap)
	{
		System.out.println("in del cake dtls "+cakeId);
		flashMap.addFlashAttribute("message",cakeService.deleteCakeDetails(cakeId));
		return "redirect:/admin/cakeList";//http://localhost:7070/spring-mvc-boot/admin/cakeList 
	}
	
	@RequestMapping("/adminMenu")
	public String showAdminMenu() {
		System.out.println("in adminMenu");
		return "/admin/adminMenu";
	}
	
}
