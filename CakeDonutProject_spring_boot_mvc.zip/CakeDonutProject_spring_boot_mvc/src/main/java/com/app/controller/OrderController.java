package com.app.controller;

import java.time.LocalDate;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Cake;
import com.app.pojos.Customer;
import com.app.pojos.Order;
import com.app.service.ICustomerService;
import com.app.service.IOrderService;

@Controller
@RequestMapping("/order")
public class OrderController {
	@Autowired
	private IOrderService orderService;
	
	@PostMapping("/save")
	public String SaveOrder(@RequestParam @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate orderDate,@RequestParam String orderName ,@RequestParam String category,@RequestParam int quantity,@RequestParam double price,HttpSession session)
	{
		
		System.out.println("in save order"+orderDate);
		Order newOrder=new Order(orderDate,quantity,price,category,orderName);
		newOrder.setCustomerOrder((Customer)session.getAttribute("customer"));
		newOrder.setOrdercake((Cake)session.getAttribute("cake"));
		System.out.println("order......"+newOrder);
		String msg=orderService.saveOrder(newOrder);
		
		//return "/payment";
		return "/order/ordersuccess";

	}

}
