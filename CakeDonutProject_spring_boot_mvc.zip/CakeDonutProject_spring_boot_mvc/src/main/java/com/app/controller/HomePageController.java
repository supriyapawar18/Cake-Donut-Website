package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomePageController {
	public HomePageController() {
		System.out.println("in ctor of "+getClass().getName());
	}
	@RequestMapping("/")
	public String showHomePage()
	{
		System.out.println("in show home page");
		return "/index";//actual view name :/WEB-INF/views/index.jsp
	}

	@RequestMapping("/aboutus")
	public String showAboutUsPage()
	{
		System.out.println("in show About Us page");
		return "/aboutus";
	}
	
	@RequestMapping("/contactus")
	public String showContactUsPage()
	{
		System.out.println("in show Contact Us page");
		return "/contactus";
	}

	@RequestMapping("/products")
	public String showProductPage() {
		System.out.println("in Products page");
		return "/products";
	}
	@RequestMapping("/orderinformation")
	public String orderinfo()
	{
		System.out.println("in order page");
		return "/orderinformation";
	}
	
	@RequestMapping("/cakecustomerlist")
	public String showlist()
	{
		System.out.println("in cake view by customer list page");
		return "/customer/cakecustomerlist";
	}
	
	@RequestMapping("/ordersuccess")
	public String showpayment()
	{
		System.out.println("in payment success page");
		return "/order/ordersuccess";
	}
	
	@RequestMapping("/payment")
	public String showpaymentPage() {
		System.out.println("in Payment page");
		return "/payment";
	}

}






