package com.app.pojos;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
@Entity
@Table(name="orders")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer orderId;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name="orderDate")
	private LocalDate orderDate;
	@Column(name="quantity")
	private int quantity;
	@Column(name="price")
	private double price;
	@Column(name="category")
	private String category;
	@Column(name="orderName")
	private String orderName;
	
	  @ManyToOne
	  @JoinColumn(name="cId")
	  private Customer customerOrder;
		
		  @ManyToOne
		  @JoinColumn(name="cakeId") 
		  private Cake orderCake;
		  

	public Order(LocalDate orderDate, int quantity, double price, String category, String orderName) {
			super();
			this.orderDate = orderDate;
			this.quantity = quantity;
			this.price = price;
			this.category = category;
			this.orderName = orderName;
		}

	public Order() {

	}
	
   public Order(Integer orderId, LocalDate orderDate, int quantity, double price, String category,
			Customer customerOrder, Cake orderCake) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.quantity = quantity;
		this.price = price;
		this.category = category;
		this.customerOrder = customerOrder;
		this.orderCake = orderCake;
	}

public Customer getOrder() {
		return customerOrder;
	}

   public void setOrder(Customer order) {
		this.customerOrder = order;
	}
   public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
    public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Customer getCustomerOrder() {
		return customerOrder;
	}

	public void setCustomerOrder(Customer customerOrder) {
		this.customerOrder = customerOrder;
	}

	public Cake getOrdercake() {
		return orderCake;
	}

	public void setOrdercake(Cake ordercake) {
		this.orderCake = ordercake;
	}

	public String getOrderName() {
		return orderName;
	}

	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	@Override
	public String toString() {
		return "Order [orderDate=" + orderDate + ", orderId=" + orderId + ",orderName=" + orderName + ",category=" + category + ", quantity=" + quantity + ", price=" + price
				+ "]";
	}

}