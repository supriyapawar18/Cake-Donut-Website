package com.app.pojos;

public enum PaymentType {
VISA,PAYPAL,NETBANKING
}
