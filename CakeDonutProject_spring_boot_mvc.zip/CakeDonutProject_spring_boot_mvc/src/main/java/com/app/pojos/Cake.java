package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Cake")
public class Cake extends BaseEntityCake
{
	@Column(length = 30)
	private String cakeName;
	@Column(name="cake_Weight")
	private double cakeWeight;
	@Column(name="cake_Category")
	private String cakeCategory;
	@Column(name="cake_Price")
	private double cakePrice;
	@Lob
	@Column(columnDefinition = "MEDIUMBLOB")
	private String image;

	
	@ManyToOne
	  @JoinColumn(name = "cId") 
	  private Customer customerCake;
	
	@OneToMany(mappedBy="orderCake",cascade = CascadeType.ALL)
    private List<Order> orders=new ArrayList<>();
	
	public Cake() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cake(String cakeName, double cakeWeight, String cakeCategory, double cakePrice, String image,
			Customer customerCake, List<Order> orders) {
		super();
		this.cakeName = cakeName;
		this.cakeWeight = cakeWeight;
		this.cakeCategory = cakeCategory;
		this.cakePrice = cakePrice;
		this.image = image;
		this.customerCake = customerCake;
		this.orders = orders;
	}



	public String getCakeName() {
		return cakeName;
	}

	public void setCakeName(String cakeName) {
		this.cakeName = cakeName;
	}

	public double getCakeWeight() {
		return cakeWeight;
	}

	public void setCakeWeight(double cakeWeight) {
		this.cakeWeight = cakeWeight;
	}

	public String getCakeCategory() {
		return cakeCategory;
	}

	public void setCakeCategory(String cakeCategory) {
		this.cakeCategory = cakeCategory;
	}

	public double getCakePrice() {
		return cakePrice;
	}

	public void setCakePrice(double cakePrice) {
		this.cakePrice = cakePrice;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public Customer getCustomerCake() {
		return customerCake;
	}

	public void setCustomerCake(Customer customerCake) {
		this.customerCake = customerCake;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	@Override
	public String toString() {
		return "Cake [getCakeId()=" + getCakeId() + ", cakeName=" + cakeName + ", cakeWeight=" + cakeWeight + ", cakeCategory="
				+ cakeCategory + ", cakePrice=" + cakePrice + ", image=" + image + "]";
	}
	
}
