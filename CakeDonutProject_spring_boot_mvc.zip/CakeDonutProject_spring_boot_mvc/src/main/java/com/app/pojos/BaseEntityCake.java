package com.app.pojos;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass //inheritance in hibernate
public class BaseEntityCake {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer cakeId;

	public Integer getCakeId() {
		return cakeId;
	}

	public void setCakeId(Integer cakeId) {
		this.cakeId = cakeId;
	}
}
