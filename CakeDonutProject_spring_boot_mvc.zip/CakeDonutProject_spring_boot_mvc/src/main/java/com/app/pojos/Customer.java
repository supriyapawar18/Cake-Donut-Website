package com.app.pojos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "customers")
public class Customer extends BaseEntity {
	
	@Column(length = 20)
	private String name;
	@Column(length = 20,unique =true)
	private String email="abc@gmail.com";
	@Column(length = 20,nullable = false)
	private String password;
	@Column(name="mobile_no")
	private String mobileNo;
	@Column(name="birth_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate birthDate;
	@Column(name="address")
	private String address;
	//add a role
	@Enumerated(EnumType.STRING)
	@Column(length = 20)
	private Role role;
	
	//1 customer many Orders
	  @OneToMany(mappedBy = "customerOrder", cascade = CascadeType.ALL, orphanRemoval =true)
	  private List<Order> orders=new ArrayList<>();
	  
 //1 customer many cake
	  @OneToMany(mappedBy="customerCake",cascade = CascadeType.ALL)
	  private List<Cake> cake=new ArrayList<>();

	//one to one (bi dir) : inverse 
//	@OneToOne(mappedBy = "customer",cascade = CascadeType.ALL)
//	private PaymentMode customerPayment;
	  
	//uni dir association between entity n value type(embeddable)
//	@Embedded //optional : added only for understanding
//	private PaymentMode mode;
	
	public Customer() {
		System.out.println("in customer ctor");
	}
	
	public Customer(String name, String email, String password, String mobileNo, LocalDate birthDate, String address,
			Role role, List<Order> orders, List<Cake> cake) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.mobileNo = mobileNo;
		this.birthDate = birthDate;
		this.address = address;
		this.role = role;
		this.orders = orders;
		this.cake = cake;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public LocalDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	

	
	
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}

	public List<Order> getOrders() {
		return orders;
	}


   public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
   public List<Cake> getCake() {
		return cake;
	}
   public void setCake(List<Cake> cake) {
		this.cake = cake;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", email=" + email + ", mobileNo=" + mobileNo + ", birthDate=" + birthDate
				+ ",address=" +address+ ", getId()=" + getId() +"  "+ role;
	}	

}
