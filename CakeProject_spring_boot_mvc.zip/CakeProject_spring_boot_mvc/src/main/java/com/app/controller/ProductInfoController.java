package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.dao.IProductDao;
import com.app.pojos.Product;


@Controller
@RequestMapping("/admin")
public class ProductInfoController 
{
	
	@Autowired
	IProductDao ProductDao;
	
	public ProductInfoController() {
		System.out.println("in ctor " + getClass().getName());
	}
	
	@GetMapping("/productinformation")
	public String viewProductInfo(Model model) {
		//List<Product> productList = ProductDao.getAllProducts(); 
		//model.addAttribute("allProducts",productList);
		//model.addAttribute("product",new Product());
        return "/admin/productinformation";
	}
	@PostMapping("/product/add")
	public String addProducts(@ModelAttribute ("product") Product product)
	{
		ProductDao.addProduct(product);
		return "redirect:/productinformation";
	}
//	@GetMapping("/viewProduct/{productId}")
//	public String displayProduct(@PathVariable("productId") int productId,Model model)
//	{
//		Product product=ProductDao.getProductById(productId);
//		model.addAttribute("product", product);
//		return "displayProduct";
//	}
//	@GetMapping("/delete/{productId}")
//	public String deleteProduct(@PathVariable("productId") int productId)
//	{
//		Product product=ProductDao.getProductById(productId);
//		ProductDao.deleteProduct(product);
//		return "redirect:/productinformation";
//	}
//
//	@GetMapping("/update/{productId}")
//	public String updateProduct(@PathVariable("productId") int productId, Model model) 
//	{
//		Product product= ProductDao.getProductById(productId);
//		model.addAttribute("product", product);
//	
//		return "productinformation";
//	}
}


