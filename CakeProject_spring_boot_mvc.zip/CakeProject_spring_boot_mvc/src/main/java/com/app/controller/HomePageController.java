package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomePageController {
	public HomePageController() {
		System.out.println("in ctor of "+getClass().getName());
	}
	@RequestMapping("/")
	public String showHomePage()
	{
		System.out.println("in show home page");
		return "/index";//actual view name :/WEB-INF/views/index.jsp
	}

	@RequestMapping("/aboutus")
	public String showAboutUsPage()
	{
		System.out.println("in show About Us page");
		return "/aboutus";//actual view name :/WEB-INF/views/index.jsp
	}
//	@GetMapping("/aboutus")
//	public String aboutPage() {
//		
//		return "/aboutus";
//	}
	@RequestMapping("/products")
	public String showProductPage() {
		System.out.println("in Products page");
		return "/products";
	}
	@RequestMapping("/productinformation")
	public String showProductInfoPage() {
		System.out.println("in ProductsInfo page");
		return "/productinformation";
	}
}






