package com.app.controller;

import java.util.Arrays;
import java.util.Iterator;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Role;
import com.app.pojos.Customer;
import com.app.service.ICustomerService;

//add ...... to send /WEB-INF/views/customer/login.jsp) to clnt
@Controller
@RequestMapping("/customer")  //<a href=requestmapping ch url/getmapping url>Login</a>
public class CustomerController {
	// dependency : service layer i/f
	@Autowired
	private ICustomerService customerService;

	public CustomerController() {
		System.out.println("in ctor " + getClass().getName());
	}
	
	//add a request handling method to show registration form for a new vendor
	//to enable 2 way form binding : add EMPTY pojo instance in the model map
	@GetMapping("/register")
	public String showCustomerRegistrationForm(Model map)
	{
		System.out.println("in show reg form");
		map.addAttribute("customer_dtls", new Customer());
		System.out.println("map "+map);//populated map 
		return "/customer/register";//actual view name : /WEB-INF/views/admin/register.jsp
	}
	//add a request hadnling method for processing reg form
//	@PostMapping("/register")
//	public String processRegFrom(@ModelAttribute(name = "customer_dtls") Customer c,BindingResult result,RedirectAttributes flashMap)
//	{
//		System.out.println("in process reg form "+c);
//		System.out.println("binding result "+result);
//		flashMap.addFlashAttribute("message", customerService.registerCustomer(c));
//		return "redirect:/index";
//	}
@PostMapping("/register")
	public String processRegFrom(@Valid Customer c, BindingResult result, RedirectAttributes flashMap) {
		System.out.println("in process reg form " + c); 
		System.out.println("binding result " + result);
		c.setRole(Role.valueOf("CUSTOMER"));
		if(result.hasErrors())
		{
			System.out.println("P.L errors"+result.toString());
			
			return "/index";
		}
		flashMap.addFlashAttribute("message", customerService.registerCustomer(c));
		return "redirect:/";
	}
//	//add init style method to display the dependency
//	@PostConstruct
//	public void anyMethod()
//	{
//		System.out.println("in init of "+getClass().getName()+" "+customerService);
//	}

	@GetMapping("/login")
	public String showLoginForm() {
		System.out.println("in show login form");
		return "/customer/login";// actual view name : /WEB-INF/views/customer/login.jsp
	}

	// add a req handling method to process the form
	// display (sop) email n pwd
	@PostMapping("/login")
	public String processLoginForm(@RequestParam String email, @RequestParam String password,
			Model map,HttpSession session) {
		System.out.println("in process login form " + email + " " + password);
		// invoke service's method for validation
		try {
			Customer validatedUser = customerService.authenticateUser(email, password);
			// successful login
			// add a mesg Admin/Vendor login successful
			session.setAttribute("message", validatedUser.getRole() + " login successful!");
			//add validated user details in session scope , to remember it till logout
			session.setAttribute("products", validatedUser);
			// if user : vendor => redirect the clnt to details page
			// (/WEB-INF/views/vendor/vendor_details.jsp)
			// Resp is sent to the clnt SC 302 | header : location : /vendor/details cookie
			// , body : empty
			// clnt browser sends a new request : http://host:port/day14/vendor/details ,
			// method=get
			if (validatedUser.getRole().equals(Role.CUSTOMER))
				return "redirect:/products";
			// SC(WC) response.sendRedirect(response.encodeRedirectURL("/vendor/details"));
			// if user : admin => redirect the clnt to vendor list page ,accessible only to
			// admin
			// (/WEB-INF/views/admin/list.jsp)
			return "redirect:/admin/customerList";//UserController ---> redirect view name ---> FC
			//SC repsonse.sendRedirect(response.encideRedirectURL("/admin/list"));
			//tmp resp is sent to clnt : SC 302 | location=/admin/list;jsessionid=dgsdf456345| empty content
			//clnt sends NEXT request http://host:port/spring-mvc/boot/admin/list;jsessionid=dgsdf456345

		} catch (RuntimeException e) {
			e.printStackTrace();
			// failed login
			// add err mesg as the model attribute
			map.addAttribute("message", "Invalid Login , Please Retry");
			// forward the client to login page , highlighted with error mesg.
			return "/customer/login";// actual view name : /WEB-INF/views/customer/login.jsp
		}

	}
	//add a method for user(vendor|admin) logout
//	@GetMapping("/logout")
//	public String logout(HttpSession session,Model map,HttpServletRequest request,HttpServletResponse resp)
//	{
//		System.out.println("in logout "+map);
//		//get user details from session scope n add it under current request scope
//		map.addAttribute("products",session.getAttribute("products"));
//		//invalidate session
//		session.invalidate();
//		//How to auto navigate the clnt to the next page (eg : home page) after a dly ?
//		//Method of HttpServletRespose : public void setHeader(String name,String value)
//		resp.setHeader("refresh", "5;url="+request.getContextPath());
//		return "/customer/logout";//actual view name /WEB-INF/views/customer/logout.jsp 
//	}
//	
//	@GetMapping("/details")
//	public String showCustomerDetails() {
//		System.out.println("in show customer details");
//		return "/customer/customer_details";// forward view --->
//		//actual view name : /WEB-INF/views/customer/customer_details.jsp
//	}
	@GetMapping("/products")
	public String showCustomerDetails() {
		System.out.println("in show products details");
		return "/products";// forward view --->
		//actual view name : /WEB-INF/views/customer/customer_details.jsp
	}
}
