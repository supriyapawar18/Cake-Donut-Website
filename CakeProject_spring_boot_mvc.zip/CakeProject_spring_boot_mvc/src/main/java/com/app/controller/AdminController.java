package com.app.controller;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.FlashMap;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Customer;
import com.app.service.ICustomerService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	//dependency : service layer i/f
	@Autowired
	private ICustomerService customerService;
	public AdminController() {
		System.out.println("in ctor of "+getClass().getName());
	}
	//add a req handling method to list all vendors
	@GetMapping("/customerList")
	public String listCustomers(Model map)
	{
		System.out.println("in list customers...");
		map.addAttribute("customer_list",customerService.listAllCustomers());
		return "/admin/customerList";//actual view name : /WEB-INF/views/admin/list.jsp
	}
	//add a req handling method to delete a specific vendor n REDIRECT client to list page 
	@GetMapping("/delete")
	public String deleteCustomerDetails(@RequestParam int cid,RedirectAttributes flashMap)
	{
		System.out.println("in del customer dtls "+cid);
		//invoke service layer method
		//Adding an attribute under flash scope (visible till the next request coming from SAME clnt)
		flashMap.addFlashAttribute("message",customerService.deleteCustomerDetails(cid));
		return "redirect:/admin/customerList";//what will be the URL of the next request : http://localhost:7070/spring-mvc-boot/admin/list 
	}
	
	@RequestMapping("/adminMenu")
	public String showAdminMenu() {
		System.out.println("in adminMenu");
		return "/admin/adminMenu";
	}
	

}
