//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.servlet.mvc.support.RedirectAttributes;

//package com.app.controller;
//
//import java.util.List;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpRequest;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.servlet.mvc.support.RedirectAttributes;
//
//import com.app.pojos.Customer;
//import com.app.pojos.Product;
//import com.app.service.IProductService;
//
//@Controller
//@RequestMapping("/product")
//public class ProductController {
//	
//	@Autowired
//	private IProductService productService;
//	
//	public ProductController() {
//		System.out.println("in ctrl of "+getClass().getName());
//	}
////	@GetMapping("/productinformation")
////	public String showProductInfoForm(Model map)
////	{
////		public String showProductInfo() {
////			System.out.println("in product Info");
////			return "/admin/productinformation";
////			map.addAttribute("product", new Product());
////		System.out.println("map "+map);//populated map 
////		return "/admin/productinformation";//actual view name : /WEB-INF/views/admin/register.jsp
////	}
////	}
//	//add a request hadnling method for processing reg form
//	@PostMapping("/productinformation")
//	public String processRegFrom(@ModelAttribute(name = "product") Product product,BindingResult result,RedirectAttributes flashMap)
//	{
//		System.out.println("in process product form "+product);
//		System.out.println("binding result "+result);
//		flashMap.addFlashAttribute("message", productService.addProduct(product));
//		return "redirect:/admin/productinformation";
//	}
//
//	@GetMapping("/productList")
//	public String listProducts(Model map)
//	{
//		System.out.println("in list Products...");
//		map.addAttribute("product_list",productService.getAllProducts());
//		return "/admin/productList";//actual view name : /WEB-INF/views/admin/list.jsp
//	}
//
//	//add a req handling method to delete a specific vendor n REDIRECT client to list page 
//
//	@GetMapping("/delete")
//	public String deleteProduct(@RequestParam int pid,RedirectAttributes flashMap)
//	{
//		System.out.println("in del product dtls "+pid);
//		//invoke service layer method
//		//Adding an attribute under flash scope (visible till the next request coming from SAME clnt)
//		flashMap.addFlashAttribute("message",productService.deleteProduct(pid));
//		return "redirect:/admin/productList";//what will be the URL of the next request : http://localhost:7070/spring-mvc-boot/admin/list 
//	}
//	@RequestMapping("/productList")
//	public String showProducts() {
//		System.out.println("in manage products ");
//		return "/admin/productList";
//	}
//	
//	
//	@GetMapping("/list")
//	public String showList(@RequestParam Model map) {
//		System.out.println("in show prod list");
//		map.addAttribute("productList", productService.getProductList());
//		return "/products/list";
//	}
//	
//	@PostMapping("/list")
//	public String processProducts(@RequestParam List<Integer> productIds, Model map) {
//		List<Product> prodList = productService.getProductList(productIds);
//		int sum = 0;
//		for(Product p : prodList) {
//			sum+=p.getPrice();
//		}
//		map.addAttribute("cartList", prodList);
//		map.addAttribute("cartValue", sum);
//		return "/products/cartPage";
//	}
//	
////	@GetMapping("/logout")
////	public String processLogout(HttpSession session, HttpServletRequest request, HttpServletResponse resp)
////	{
////		System.out.println("logging out user");
////		session.invalidate();
////		resp.setHeader("refresh", "5;url="+request.getContextPath());
////		return "/product/logout";
////	}
//	
//}
