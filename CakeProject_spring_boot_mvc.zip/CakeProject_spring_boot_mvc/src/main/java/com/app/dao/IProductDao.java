package com.app.dao;

import java.util.List;

import com.app.pojos.Customer;
import com.app.pojos.Product;


public interface IProductDao 
{
	public boolean addProduct(Product product);
	public boolean updateProduct(Product product);
	public boolean deleteProduct(Product product);
	public Product getProductById(int productId);
	List<Product> getAllProducts();
	

}
