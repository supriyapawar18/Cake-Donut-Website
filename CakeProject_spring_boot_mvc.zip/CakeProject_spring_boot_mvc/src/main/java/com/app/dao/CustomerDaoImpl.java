package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Role;
import com.app.pojos.Customer;

@Repository // mandatory to tell SC that following class is DAO n enables exc translation
			// mechanism
public class CustomerDaoImpl implements ICustomerDao {
	// dependency
	@Autowired // autowire=byType
//	private SessionFactory sf;
	private EntityManager mgr;
	//EntityManager : javax.persistence.EntityManager => equivalent to Hibernate session
	//Ir represents L1 cache (entity level cache) + represents a wrapper around pooled out db con from Hikari pool
	//Hikari : def cn pool vendor (fastest!)
	//EntityManager : has similar API as Session.
	//Session -- save/persist , get , createQuery, JPQL ,update,delete
	//EntityManager -- persist, find,createQuery, JPQL ,merge,remove
	//for more details ref to Java EE api docs.

	@Override
	public Customer authenticateUser(String em, String pass) {
		String jpql = "select c from Customer c where c.email = :em and c.password=:pass";
		return mgr.createQuery(jpql, Customer.class).
				setParameter("em", em).setParameter("pass", pass)
				.getSingleResult();
	}

	@Override
	public List<Customer> listAllCustomers() {
		String jpql="select c from Customer c where c.role=:rl";		
		return mgr.createQuery(jpql, Customer.class).setParameter("rl", Role.CUSTOMER).getResultList();
	}

	@Override
	public Customer getCustomerDetails(int customerId) {
		
		return mgr.find(Customer.class, customerId);//int---> Integer ---> Object
	}

	@Override
	public String deleteCustomerDetails(Customer v) {
		//Assumption : service layer will validate n pass existing vendor ref to the dao layer.
		mgr.remove(v);
		return "Customer details with ID "+v.getId()+" deleted....";
	}

	@Override
	public String registerCustomer(Customer v) {
		String mesg="Customer registration failed....";
		mgr.persist(v);
		mesg="Customer registration successful "+v.getId();
		return mesg;
	}
	
	
	

}
