package com.app.service;

import java.util.List;

import com.app.pojos.Customer;

public interface ICustomerService {
	Customer authenticateUser(String em,String pass);
	//add a method to return a customer list
		List<Customer> listAllCustomers();
		//add a method to delete customer details
		String deleteCustomerDetails(int customerId);
		// add a method to register  new  customer details
		String registerCustomer(Customer c);
}
