//package com.app.service;
//
//import java.util.List;
//
//import org.hibernate.HibernateException;
//import org.hibernate.SessionFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.app.pojos.Product;
//import com.app.dao.ICustomerDao;
//import com.app.dao.IProductDao;
//
//
//@Service // mandatory : to tell SC following class is a B.L supplier.
//@Transactional // mandatory : to tell Spring supplied tx mgr bean , to handle txs
//				// automatically.
//public class ProductServiceImpl implements IProductService
//{
////	// dependency : DAO layer
////		@Autowired
////		private IProductDao productDao;
//	@Autowired
//	SessionFactory sessionFactory;
//
//	public boolean addProduct(Product product) {
//		try {
//			sessionFactory.getCurrentSession().saveOrUpdate(product);
//			return true;
//		} catch (HibernateException e) {
//			e.printStackTrace();
//			return false;
//		}
//	}
//
//	public boolean updateProduct(Product product) {
//		try {
//			sessionFactory.getCurrentSession().update(product);
//			return true;
//		} catch (HibernateException e) {
//			e.printStackTrace();
//			return false;
//		}
//	}
//
//	public boolean deleteProduct(Product product) {
//		try {
//			sessionFactory.getCurrentSession().delete(product);
//			return true;
//		} catch (HibernateException e) {
//			e.printStackTrace();
//			return false;
//		}
//	}
//
//	public Product getProductById(int productId) {
//		Product product=sessionFactory.getCurrentSession().get(Product.class, productId);
//		return product;
//	}
//
//	public List<Product> getAllProducts() {
//
//		@SuppressWarnings("unchecked")
//		List<Product> list=sessionFactory.getCurrentSession().createQuery("FROM Product").getResultList();
//		return list;
//	
//	}
//
//	
//}
//
//package com.app.service;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.app.dao.IProductDao;
//import com.app.pojos.Product;
//@Service
//@Transactional
//public class ProductServiceImpl implements IProductService {
//	
//	@Autowired
//	private IProductDao dao;
//	
//	@Override
//	public List<Product> getProductList() {
//		System.out.println("getting product list");
//		return dao.getProductList();
//	}
//
//	@Override
//	public List<Product> getProductList(List<Integer> ids) {
//		return dao.findAllById(ids);
//	}
//
//	@Override
//	public String addProduct(Product product) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//}

