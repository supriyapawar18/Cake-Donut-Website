//package com.app.service;
//
//import java.util.List;
//
//import com.app.pojos.Product;
//
//
//public interface IProductService 
//{
//	public boolean addProduct(Product product);
//	public boolean updateProduct(Product product);
//	public boolean deleteProduct(Product product);
//	public Product getProductById(int productId);
//	List<Product> getAllProducts();
//}

package com.app.service;

import java.util.List;

import com.app.pojos.Customer;
import com.app.pojos.Product;

public interface IProductService {
	
	List<Product> getProductList();
	
	List<Product> getProductList(List<Integer> ids);
	// add a method to add  new  product details
			String addProduct(Product product);
}

