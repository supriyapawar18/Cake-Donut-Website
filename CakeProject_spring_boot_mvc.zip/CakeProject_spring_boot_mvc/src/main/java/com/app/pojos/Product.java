package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "products")
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer productId;
	@Column(length = 30)
	private String productName;
	@Column(name="product_Weight")
	private double productWeight;
	@Column(name="product_Category")
	private String productCategory;
	@Column(name="product_Price")
	private double productPrice;
	
	@ManyToOne
	@JoinColumn(name = "cId")
	private Customer customer;

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(Integer productId, String productName, double productWeight, String productCategory,
			double productPrice, Customer customer) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productWeight = productWeight;
		this.productCategory = productCategory;
		this.productPrice = productPrice;
		this.customer = customer;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductWeight() {
		return productWeight;
	}

	public void setProductWeight(double productWeight) {
		this.productWeight = productWeight;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productWeight=" + productWeight
				+ ", productCategory=" + productCategory + ", productPrice=" + productPrice + ", customer=" + customer
				+ "]";
	}
}



