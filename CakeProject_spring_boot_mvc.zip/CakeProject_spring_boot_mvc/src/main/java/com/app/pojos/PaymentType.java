package com.app.pojos;

public enum PaymentType {
CREDIT_CARD,PAYTM,GPAY,NETBANKING
}
