package com.app.pojos;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="order")
public class Order {
	private LocalDate orderDate;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer orderId;
	private int quantity;
	private double price;
	
	

	@ManyToOne
	@JoinColumn(name = "oId")
	private Customer customerOrder;


    public Order() {

	}
	



	public Order(LocalDate orderDate, Integer orderId, int quantity, double price, Customer customerOrder) {
		super();
		this.orderDate = orderDate;
		this.orderId = orderId;
		this.quantity = quantity;
		this.price = price;
		this.customerOrder = customerOrder;
	}



	public LocalDate getOrderDate() {
		return orderDate;
	}



	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}



	public Integer getOrderId() {
		return orderId;
	}



	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}



	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}



	public Customer getCustomer() {
		return customerOrder;
	}



	public void setCustomer(Customer customerOrder) {
		this.customerOrder = customerOrder;
	}



	@Override
	public String toString() {
		return "Order [orderDate=" + orderDate + ", orderId=" + orderId + ", quantity=" + quantity + ", price=" + price
				+ "]";
	}
	
	
	

}
